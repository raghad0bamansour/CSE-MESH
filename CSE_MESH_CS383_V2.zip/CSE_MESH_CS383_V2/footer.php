<?php 

echo "
<div class=\"footer\">
  <footer>
  <p>CSE MESH.<br>
  Copyright © 2021.
  <br><a href=\"hege@example.com\">CSEMESH@gmail.com</a></p>
</footer>
</div>";
?>