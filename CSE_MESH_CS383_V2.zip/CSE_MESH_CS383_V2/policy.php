<!DOCTYPE html>
<html>
<head>
<title>Policy</title>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="css/policy10.css">
</head>
<body>
<?php include "bar2.php"; ?>

<img class="policy" src="img/policy1.png" alt="">
<div class="div1">
  <h1><strong>Policies for CSE MESH</strong></h1>
  <p>
    <ul type="square">
      <li>Teacher and student can cancel the booked office hour before 24 hours.</li>
      <li>You can only book for current week.</li>
      <li>Database cleand every Thursday.</li>
      <li>Only department's taechers.</li>
      <li>For the student, you can only booked two slot for each teaher.</li>
      <li>teacher can cancel the booked hour.</li>
    </ul>
  </p>
</div>

<?php include "footer.php"; ?>
</div>
</body>
</html>
