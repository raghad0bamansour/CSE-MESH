<!DOCTYPE html>
<html>
<head>
<title>About Us</title>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="css/policy10.css">
</head>
<body>

<?php include "bar2.php"; ?>

<img class="policy" src="img/about1.png" alt="">
<div class="div1">
  <h1><strong>About CSE MESH</strong></h1>
  <h5>At CSE_MESH.com, we believe that teachers and students deserve<br> to have a professional system to schedule a meeting. Our goal is to<br> provide all the features needed to make the teaching and learning process<br> successful. We are excited to help you in your journey!
  </h5>
</div>

<?php include "footer.php"; ?> 
</body>
</html>
